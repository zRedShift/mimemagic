<html>
<head>
<title>Test</title>
</head>
<body>
<?php echo 'Test'; ?>
</body>
</html>
